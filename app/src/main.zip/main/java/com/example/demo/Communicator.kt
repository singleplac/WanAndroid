package com.example.demo

import android.widget.EditText

interface  Communicator {
    fun passDataCom( editTextInput : String)
}