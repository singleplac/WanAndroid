package com.example.demo

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.HandlerCompat.postDelayed
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class ItemFrag : Fragment() {

    private lateinit var communicator: Communicator
    private lateinit var layoutManager:LinearLayoutManager
    var ItemRecyclerview : RecyclerView ?=null
    var progressBar: ProgressBar ?=null

    var ItemList = ArrayList<Item>()
    var page = 0
    var isLoading = false

    var last_page : Button ?= null
    var next_page : Button ?= null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var view = inflater.inflate( R.layout.item_frag, container,false)
        ItemRecyclerview = view.findViewById( R.id.ItemRecyclerview )

        progressBar = view.findViewById( R.id.processorBar )
        last_page = view.findViewById( R.id.last_page)
        next_page = view.findViewById( R.id.next_page)

        return view
    }

    //使用layoutManager管理Recyclerview
    override fun onActivityCreated( savedInstanceState: Bundle? ) {

        super.onActivityCreated(savedInstanceState)


        layoutManager =  LinearLayoutManager(activity)
        ItemRecyclerview ?.layoutManager = layoutManager

        //获取Service接口的动态代理对象
        var appService = ServiceCreator.create(AppService::class.java)

        getPage(appService,0)

        //添加滑动窗口监控
        ItemRecyclerview?.addOnScrollListener(object : RecyclerView.OnScrollListener() {

            var pageLimit = 0

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {

                if (dy > 0){ //向下滚动

                    //当前页面含有的个数(11个左右）
                    val visibleItemCount  = layoutManager.childCount
                    //划过的个数
                    val pastVisibleItem = layoutManager.findFirstCompletelyVisibleItemPosition()
                    val FVItemPos = layoutManager.findFirstVisibleItemPosition()
                    val LCItempos = layoutManager.findLastCompletelyVisibleItemPosition()
                    val LVItempos = layoutManager.findLastVisibleItemPosition()

                    val total = ItemList.size
//                    Log.d ("MainActivity","childCount is $visibleItemCount")
//                    Log.d ("MainActivity","postVisibleItem is $pastVisibleItem")
//                    Log.d ("MainActivity","pFirstVisibleItem is $FVItemPos")
                    Log.d ("MainActivity","Itemlist.size is $total")
//                    Log.d ("MainActivity","LastCompletelyVisibleItem is $LCItempos")
                    Log.d ("MainActivity","LastVisibleItem.size is $LVItempos")

                    if (!isLoading ){

                        appService.getAppData( page ).enqueue( object : retrofit2.Callback<test> {
                            override fun onResponse(call: retrofit2.Call<test>, response: retrofit2.Response<test>) {

                                val responseData = response.body()
                                pageLimit  = responseData?.data!!.size
                            }
                            override fun onFailure(call: retrofit2.Call<test>, t: Throwable) {
                                t.printStackTrace()
                            }
                        })
                        if(visibleItemCount  + pastVisibleItem >= pageLimit){

                            //滑到底部只展示当前页的20个
                            page ++
                            getPage(appService, page)

//                            Toast.makeText(context,"next page is $page++",Toast.LENGTH_SHORT).show()

                        }
                    }


                }
            }
        })

        last_page?.setOnClickListener{
            getPage(appService,page++)
            Toast.makeText(context,"last page is $page",Toast.LENGTH_SHORT).show()

        }

        next_page?.setOnClickListener{
            getPage(appService,page--)
            Toast.makeText(context,"next page is $page",Toast.LENGTH_SHORT).show()
        }

    }


    private fun getPage( appService: AppService, page:Int) {

        isLoading = true
        progressBar?.visibility = View.VISIBLE
        var offset = 0
        var size = 0
        var currpage  = 0



        appService.getAppData( page ).enqueue( object : retrofit2.Callback<test> {
            override fun onResponse(call: retrofit2.Call<test>, response: retrofit2.Response<test>) {

                val responseData = response.body()

                responseData?.data?.datas?.forEach {

                    var item = Item(it.title, it.shareUser, it.link, responseData?.data!!.curPage)
                    ItemList.add(item)
                    val adapter = ItemAdapter(ItemList)
                    ItemRecyclerview?.adapter = adapter

                }
                offset = responseData?.data!!.offset
                size = responseData?.data!!.size
                currpage = responseData?.data!!.curPage

                Log.d("MainActivity", "Do you have something? offset of page $currpage is $offset")


                //print current page
//                val curPage : Int = responseData?.data!!.curPage
//                Toast.makeText(parentFragment?.context,"page is $curPage",Toast.LENGTH_SHORT).show()
//                Log.d("MainActivity", "page is $curPage")

            }
            override fun onFailure(call: retrofit2.Call<test>, t: Throwable) {
                t.printStackTrace()
            }
            })
        var lastposition = layoutManager.findLastVisibleItemPosition()
        Log.d("MainActivity", "offset of page $currpage is $offset")
        val pos = offset + size
        layoutManager.scrollToPositionWithOffset(offset, pos )

        isLoading = false
        progressBar?.visibility = View.GONE
    }



    //创建自己的Adapter
    //传入list
    inner class ItemAdapter (val itemlist : List<Item>): RecyclerView.Adapter<ItemAdapter.ViewHolder>(){


        inner class ViewHolder (view : View): RecyclerView.ViewHolder(view){

            //继承RecyclerView.ViewHolder

            var title: TextView = view.findViewById( R.id.title )
            var shareUser : TextView = view.findViewById( R.id.shareUser )
            var curpage : TextView = view.findViewById( R.id.curPage )

        }


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            //创建ViewHolder实例

            //引入单个item的XML

            var view  = LayoutInflater.from( parent.context ).inflate( R.layout.item, parent,false)
            val holder = ViewHolder(view)
            val title :TextView = view.findViewById( R.id.title )
            communicator = activity as Communicator


            //点击标题跳转到另一个fragment
            title.setOnClickListener {
                Toast.makeText( parent.context,"${title.text} is clicked", Toast.LENGTH_SHORT).show()

                val item  = itemlist[holder.adapterPosition]
                val title  = item.title

                if (title !=null && context !=null ){

                    //调用接口传参
                    communicator.passDataCom( item.link )

                }

            }

            return holder

        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {

            //设置参数

            val item = itemlist[position]

            holder.title.text = item.title
            holder.shareUser.text = item.shareUser
            holder.curpage.text = "curpage ${item.curpage}"
        }

        override fun getItemCount() = itemlist.size

    }


}
