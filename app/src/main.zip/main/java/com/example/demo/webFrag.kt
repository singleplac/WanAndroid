package com.example.demo


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebView.RENDERER_PRIORITY_BOUND
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment


class webFrag : Fragment(){

    var webpage :WebView ?= null
    var weblink :String ?= ""

    //引入布局
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate( R.layout.web_frag, container,false)

        webpage = view.findViewById( R.id.webpage )
        weblink = arguments?.getString("link")

        //设置网页参数
        webpage?.apply{
            settings.javaScriptEnabled = true
            settings.blockNetworkImage = true
            settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
            settings.blockNetworkImage = false
            //设置 缓存模式
            getSettings().setCacheMode(WebSettings.LOAD_DEFAULT)
            // 开启 DOM storage API 功能
            getSettings().setDomStorageEnabled(true)
            webViewClient = WebViewClient()
            loadUrl(weblink!!)
        }


        return view
    }




}