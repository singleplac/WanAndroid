package com.example.demo

class Item (val title:String, val shareUser: String, val link: String,val curpage: Int)